package org.devio.`as`.proj.common.city

import org.devio.hi.ui.cityselector.District

internal data class CityModel(val total: Int, val list: List<District>)