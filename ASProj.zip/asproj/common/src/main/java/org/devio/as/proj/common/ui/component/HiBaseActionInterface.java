package org.devio.as.proj.common.ui.component;

public interface HiBaseActionInterface {

}
