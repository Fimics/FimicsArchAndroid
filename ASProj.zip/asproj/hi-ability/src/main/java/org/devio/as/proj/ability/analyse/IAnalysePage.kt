package org.devio.`as`.proj.ability.analyse

interface IAnalysePage {
    fun getPageName(): String
}