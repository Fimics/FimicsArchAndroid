# [AndroidUI核心组件剖析与实战](https://class.imooc.com/sale/mobilearchitect)


AndroidUI核心组件剖析与实战。

### 目录

- [如何运行](#如何运行)
- [课程增值电子书](https://doc.devio.org/as/)


### 如何运行

1. 本仓库项目可独立运行
2. 将`https://git.imooc.com/class-85/as-frameworkUI.git` clone下来
3. 建议用[Android Studio 4.1](https://developer.android.com/studio/preview)及以上版本打开项目运行


