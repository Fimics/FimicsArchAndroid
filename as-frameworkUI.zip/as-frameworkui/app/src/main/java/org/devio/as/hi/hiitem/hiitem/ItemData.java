package org.devio.as.hi.hiitem.hiitem;

public class ItemData {
    public static final int TYPE_TOP_TAB = 1;
    public static final int TYPE_BANNER = 2;
    public static final int TYPE_GRID_ITEM = 3;
    public static final int TYPE_ACTIVITY = 4;
    public static final int TYPE_ITEM_TAB = 5;
    public static final int TYPE_VIDEO = 6;
    public static final int TYPE_IMAGE = 7;


    public int itemType;//item的类型

}
