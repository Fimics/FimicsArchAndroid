package org.devio.as.hi.hiitem.hiitem.old_demo;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class HiViewHolder extends RecyclerView.ViewHolder {
    public HiViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
