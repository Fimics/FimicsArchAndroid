package org.devio.hi.ui.app.demo.banner;


import org.devio.hi.ui.banner.core.HiBannerMo;

public class BannerMo extends HiBannerMo {

}
