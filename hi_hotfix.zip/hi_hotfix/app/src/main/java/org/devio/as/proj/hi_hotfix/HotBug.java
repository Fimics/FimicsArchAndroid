package org.devio.as.proj.hi_hotfix;

public class HotBug {
    public static String test() {
        return "bug";
    }
}
