package com.peace.hybrid.creator

interface IWebCreator<T> {

    fun createDefault(): T
}