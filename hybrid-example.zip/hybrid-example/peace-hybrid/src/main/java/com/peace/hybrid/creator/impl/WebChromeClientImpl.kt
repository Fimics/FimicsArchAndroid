package com.peace.hybrid.creator.impl

import android.webkit.WebChromeClient

open class WebChromeClientImpl : WebChromeClient()