package com.peace.hybrid.global

internal enum class HybridKey {
    KEY_USER_AGENT,
    KEY_JAVASCRIPT_INTERFACE,
}