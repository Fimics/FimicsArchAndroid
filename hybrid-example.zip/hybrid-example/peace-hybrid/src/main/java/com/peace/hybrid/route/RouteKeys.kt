package com.peace.hybrid.route

/**
 * @author 傅令杰
 */
enum class RouteKeys {
    /**
     * web页面跳转必须传递的参数
     */
    URL
}
