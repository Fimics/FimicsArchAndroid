package com.example.intoflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
