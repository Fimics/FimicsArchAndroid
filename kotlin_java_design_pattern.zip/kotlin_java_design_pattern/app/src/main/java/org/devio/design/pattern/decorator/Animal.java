package org.devio.design.pattern.decorator;

/**
 * 抽象组件
 */
public interface Animal {
    void eat();
}
