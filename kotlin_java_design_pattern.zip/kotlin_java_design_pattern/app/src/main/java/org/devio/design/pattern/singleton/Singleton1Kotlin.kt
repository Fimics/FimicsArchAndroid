package org.devio.design.pattern.singleton

/**
 * 饿汉式-Kotlin实现
 */
object Singleton1Kotlin {

}