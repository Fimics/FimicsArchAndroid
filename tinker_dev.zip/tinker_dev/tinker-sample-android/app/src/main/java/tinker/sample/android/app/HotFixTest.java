package tinker.sample.android.app;

public class HotFixTest {
    public  String test(){
        return "fix from patch";
    }
}
